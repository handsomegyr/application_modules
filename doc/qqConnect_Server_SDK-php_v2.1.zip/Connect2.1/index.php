<!DOCTYPE HTML>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
<h2>欢迎使用QQ Connet SDK For PHP 2.1</h2>
请先<a href="install/">设置配置项</a><br />
或者打开doc目录下，阅读我们的文档
</body>
</html>
